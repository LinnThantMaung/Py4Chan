document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("new-thread-form");
  const threadsContainer = document.getElementById("threads-container");

  fetch("api/get_threads.php")
    .then(res => res.json())
    .then(data => {
      for (const tid in data) {
        const thread = data[tid];
        const div = document.createElement("div");
        div.innerHTML = `<a href="thread.html?tid=${tid}">${thread.title}</a>`;
        threadsContainer.appendChild(div);
      }
    });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const formData = new FormData(form);

    const res = await fetch("api/create_thread.php", {
      method: "POST",
      body: formData
    });

    if (res.ok) location.reload();
  });
});