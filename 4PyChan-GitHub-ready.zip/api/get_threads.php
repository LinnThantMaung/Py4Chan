<?php
header('Content-Type: application/json');
$state = file_get_contents('../state.json');
echo $state ?: '{}';