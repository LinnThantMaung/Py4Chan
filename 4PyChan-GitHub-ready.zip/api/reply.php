<?php
$threads = json_decode(file_get_contents('../state.json'), true);
$tid = $_POST['tid'] ?? '';
$text = htmlspecialchars($_POST['message'] ?? '');

$filename = null;
if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
  $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
  if (in_array(strtolower($ext), ['jpg', 'jpeg', 'png', 'gif'])) {
    $filename = uniqid() . "." . $ext;
    move_uploaded_file($_FILES['file']['tmp_name'], "../uploads/$filename");
  }
}

if (isset($threads[$tid])) {
  $threads[$tid]['posts'][] = [
    'text' => $text,
    'time' => date('Y-m-d H:i:s'),
    'file' => $filename
  ];
  file_put_contents('../state.json', json_encode($threads, JSON_PRETTY_PRINT));
  http_response_code(200);
} else {
  http_response_code(404);
}