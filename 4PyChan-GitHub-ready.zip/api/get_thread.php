<?php
header('Content-Type: application/json');
$tid = $_GET['tid'] ?? '';
$threads = json_decode(file_get_contents('../state.json'), true);
echo json_encode($threads[$tid] ?? []);