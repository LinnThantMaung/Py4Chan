# 4PyChan
Simple 4chan-style imageboard using HTML, CSS, JS and PHP.
